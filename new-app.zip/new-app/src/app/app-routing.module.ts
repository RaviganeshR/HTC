import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { EmployeeComponent } from './employee/employee.component';
import { AuthGuard } from './auth.guard';


const routes: Routes = [
{path:'app-login', component : LoginComponent, canActivate : [AuthGuard]},
{path:'', redirectTo: 'app-login', pathMatch: 'full'},
{path:'app-employee', component : EmployeeComponent}]
;

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
