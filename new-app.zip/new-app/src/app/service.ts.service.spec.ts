import { TestBed } from '@angular/core/testing';

import { Service.TsService } from './service.ts.service';

describe('Service.TsService', () => {
  let service: Service.TsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Service.TsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
