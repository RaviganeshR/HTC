import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
f;
Login;
  constructor(private route:Router) { }

  ngOnInit(): void {
  }

  onClickSubmit() {
    this.Login =true;
    this.route.navigateByUrl('/app-employee')
    //this.route.navigate(['/app-employee'])
 }

}
