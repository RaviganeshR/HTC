import { Component, OnInit } from '@angular/core';
import {ServiceService} from '../../service.ts.service'

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {
  employeeDta;
  constructor(private service:ServiceService) { }

  ngOnInit(): void {
    this.employeeDta = this.service.tableDta;
  }

}
