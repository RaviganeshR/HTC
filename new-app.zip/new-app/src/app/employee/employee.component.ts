import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,Validators } from '@angular/forms';
import {ServiceService} from '../service.ts.service'

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  formdata;
  employeeDta=[];
  constructor( private service: ServiceService) { }

  ngOnInit(): void {
    this.formdata = new FormGroup({
      Name: new FormControl("", Validators.compose([
         Validators.required
      ])),
      Salary: new FormControl("", Validators.compose([
        Validators.required
     ])),
     Address: new FormControl("", Validators.compose([
      Validators.required
   ])),
 
   });
  }
  onClickSubmit(data){
    this.employeeDta.push(data)
    this.service.tableDta = this.employeeDta;
    console.log(this.employeeDta)
  }
}
