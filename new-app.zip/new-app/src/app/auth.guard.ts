import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable, from } from 'rxjs';
import {LoginComponent} from '../app/login/login.component'


@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return this.loginAuth();
  }
  constructor(private Login: LoginComponent, private Router:Router) {
  }
  
  loginAuth(){
    if(this.Login.Login){
      return true;
    }else{
      this.Router.navigate(['/app-login'])
    }
  }
}
